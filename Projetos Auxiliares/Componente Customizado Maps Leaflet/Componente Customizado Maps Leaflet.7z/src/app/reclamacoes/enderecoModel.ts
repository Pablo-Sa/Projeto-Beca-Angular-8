export class Endereco{
    rua: string;
    numero: number;
    bairro: string;
    cep: string;
}