export class Coordenadas{
    latitude: number;
    longitude: number;
}